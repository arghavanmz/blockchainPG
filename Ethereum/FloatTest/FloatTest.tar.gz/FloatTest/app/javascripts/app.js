// Import the page's CSS. Webpack will know what to do with it.
import "../stylesheets/app.css";

// Import libraries we need.
import { default as Web3} from 'web3';
import { default as contract } from 'truffle-contract'

// Import our contract artifacts and turn them into usable abstractions.
import opt_artifacts from '../../build/contracts/GlobalOpt.json'

// MetaCoin is our usable abstraction, which we'll use through the code below.
//var MetaCoin = contract(metacoin_artifacts);
var GlobalOpt = contract(opt_artifacts);

// The following code is simple to show off interacting with your contracts.
// As your needs grow you will likely need to change its form and structure.
// For application bootstrapping, check out window.addEventListener below.
var accounts;
var account;

window.App = {
  start: function() {
    var self = this;

    GlobalOpt.setProvider(web3.currentProvider);

    // Get the initial account balance so it can be displayed.
    web3.eth.getAccounts(function(err, accs) {
      if (err != null) {
        alert("There was an error fetching your accounts.");
        return;
      }

      if (accs.length == 0) {
        alert("Couldn't get any accounts! Make sure your Ethereum client is configured correctly.");
        return;
      }

      accounts = accs;
      account = accounts[0];

      self.refreshValues();
    });
  },

  setStatus: function(message) {
    var status = document.getElementById("status");
    status.innerHTML = message;
  },
  
  str2float: function(str) {
    var exp = str.indexOf(".");
    var val = 0;
    if (exp > 0) {
      val = parseInt(str.slice(0,exp).concat(str.slice(exp+1,str.length)));
      exp = str.length - exp - 1;
    } else {
      val = parseInt(str);
      exp = 0;
    }
    var sgn = false;
    if (val >= 0) {
      sgn = true;
    } else {
      val = -1 * val;
    }
    return [sgn ? 1 : 0, val, exp];
  },
  
  float2str: function(flt) {
    var exp = flt[2];
    var val = flt[1];
    var sgn = flt[0];
    var str = val.toString();
    if (exp >= 0) {
      if (exp >= str.length) {
        str = "0".concat(".").concat("0".repeat(exp-str.length)).concat(str);
      } else {
        str = str.slice(0, str.length - exp).concat(".").concat(str.slice(str.length - exp,str.length));
      }
    }
    if (sgn == 0) {
      str = "-".concat(str);
    }
    return str;
  },

  refreshValues: function() {
    var self = this;

    var meta;
    var elem;
    var strA;
    var strB;
    var strC;
    var strSum;
    GlobalOpt.deployed().then(function(instance) {
      meta = instance;
    }).then(function() {
      return meta.getX(0, {from: account});
    }).then(function(a) {
      strA = self.float2str(a);
    }).then(function() {
      return meta.getX(1, {from: account});
    }).then(function(b) {
      strB = self.float2str(b);
    }).then(function() {
      return meta.getX(2, {from: account});
    }).then(function(c) {
      strC = self.float2str(c);
    }).then(function() {
      return meta.getLambda({from: account});
    }).then(function(res) {
      strSum = self.float2str(res);
    }).then(function() {
      var len = [strA.slice(strA.indexOf("."),strA.length).length,
        strB.slice(strB.indexOf("."),strB.length).length, 
        strC.slice(strC.indexOf("."),strC.length).length,
        strSum.slice(strSum.indexOf("."),strSum.length).length];
      var mlen = Math.max(len[0], len[1], len[2], len[3]);
      if (len[0] < mlen) {
        strA = strA.concat("0".repeat(mlen-len[0]));
      }
      if (len[1] < mlen) {
        strB = strB.concat("0".repeat(mlen-len[1]));
      }
      if (len[2] < mlen) {
        strC = strC.concat("0".repeat(mlen-len[2]));
      }
      if (len[3] < mlen) {
        strSum = strSum.concat("0".repeat(mlen-len[3]));
      }
      elem = document.getElementById("balanceA");
      elem.innerHTML = strA;
      elem = document.getElementById("balanceB");
      elem.innerHTML = strB;
      elem = document.getElementById("balanceC");
      elem.innerHTML = strC;
      elem = document.getElementById("balanceSum");
      elem.innerHTML = strSum;
    }).catch(function(e) {
      console.log(e);
      self.setStatus("Error getting the values...");
    });
  },

  setA: function() {
    var self = this;

    var str = document.getElementById("valueA").value;
    var flt = self.str2float(str);

    this.setStatus("Setting the value... (please wait)");

    var meta;
    GlobalOpt.deployed().then(function(instance) {
      meta = instance;
      return meta.updateX(0, flt[0] == 1 ? true : false, flt[1], flt[2], {from: account});
    }).then(function() {
      self.setStatus("Setting complete!");
      self.refreshValues();
    }).catch(function(e) {
      console.log(e);
      self.setStatus("Error setting value; see log.");
    });
  },

  setB: function() {
    var self = this;
    
    var str = document.getElementById("valueB").value;
    var flt = self.str2float(str);

    this.setStatus("Setting the value... (please wait)");

    var meta;
    GlobalOpt.deployed().then(function(instance) {
      meta = instance;
      return meta.updateX(1, flt[0] == 1 ? true : false, flt[1], flt[2], {from: account});
    }).then(function() {
      self.setStatus("Setting complete!");
      self.refreshValues();
    }).catch(function(e) {
      console.log(e);
      self.setStatus("Error setting value; see log.");
    });
  },

  setC: function() {
    var self = this;

    var str = document.getElementById("valueC").value;
    var flt = self.str2float(str);

    this.setStatus("Setting the value... (please wait)");

    var meta;
    GlobalOpt.deployed().then(function(instance) {
      meta = instance;
      return meta.updateX(2, flt[0] == 1 ? true : false, flt[1], flt[2], {from: account});
    }).then(function() {
      self.setStatus("Setting complete!");
      self.refreshValues();
    }).catch(function(e) {
      console.log(e);
      self.setStatus("Error setting value; see log.");
    });
  },

  getLambda: function() {
    var self = this;

    this.setStatus("Getting the sum... (please wait)");

    var meta;
    GlobalOpt.deployed().then(function(instance) {
      meta = instance;
    }).then(function() {
      return meta.updateLambda({from: account});
    }).then(function() {
      self.setStatus("Setting complete!");
      self.refreshValues();
    }).catch(function(e) {
      console.log(e);
      self.setStatus("Error getting the sum; see log.");
    });
  }
};

window.addEventListener('load', function() {
  // Checking if Web3 has been injected by the browser (Mist/MetaMask)
  if (typeof web3 !== 'undefined') {
    console.warn("Using web3 detected from external source. If you find that your accounts don't appear or you have 0 MetaCoin, ensure you've configured that source properly. If using MetaMask, see the following link. Feel free to delete this warning. :) http://truffleframework.com/tutorials/truffle-and-metamask")
    // Use Mist/MetaMask's provider
    window.web3 = new Web3(web3.currentProvider);
  } else {
    console.warn("No web3 detected. Falling back to http://127.0.0.1:9545. You should remove this fallback when you deploy live, as it's inherently insecure. Consider switching to Metamask for development. More info here: http://truffleframework.com/tutorials/truffle-and-metamask");
    // fallback - use your fallback strategy (local node / hosted node + in-dapp id mgmt / fail)
    window.web3 = new Web3(new Web3.providers.HttpProvider("http://127.0.0.1:9545"));
  }

  App.start();
});
